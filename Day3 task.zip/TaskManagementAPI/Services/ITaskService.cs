﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TaskManagementAPI.Models;

namespace TaskManagementAPI.Services
{
    public interface ITaskService
    {
        Task<IEnumerable<TaskManagementAPI.Models.Task>> GetTasksAsync();
        Task<TaskManagementAPI.Models.Task> GetTaskByIdAsync(int id);
        Task<TaskManagementAPI.Models.Task> CreateTaskAsync(TaskManagementAPI.Models.Task task);
        Task<bool> UpdateTaskAsync(TaskManagementAPI.Models.Task task);
        Task<bool> DeleteTaskAsync(int id);
    }
}
